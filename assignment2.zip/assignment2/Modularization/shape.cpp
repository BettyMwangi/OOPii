#include "shape.h"

std::string Shape::getName(){
    return name;
    
}

 