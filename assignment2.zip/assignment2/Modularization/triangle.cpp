#include "triangle.h"

float Triangle::area(float base, float height){
    return((base*height)/2);
}